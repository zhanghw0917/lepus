
<div class="header">
            
            <h1 class="page-title"><?php echo $this->lang->line('license'); ?></h1>
</div>
        


<div class="container-fluid">
<div class="row-fluid">    

    <div class="http-error">
        <h1><?php echo $this->lang->line('license_upgrade'); ?></h1>
        <p class="info"><?php echo $this->lang->line('you_need_upgrade_license'); ?></p>
        <p><i class="icon-home"></i></p>
        <p>&nbsp;<a href="http://www.lepus.cc" target="blank"><?php echo $this->lang->line('upgrade_license'); ?></a></p>
    </div>


