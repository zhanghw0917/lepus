<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['use_page_numbers'] = FALSE;
$config['uri_segment'] = 3;
