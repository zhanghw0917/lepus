<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$config['mailtype'] = 'html';
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp.126.com';
$config['smtp_port'] = '25';
$config['smtp_user'] = '';
$config['smtp_pass'] = '';
$config['smtp_timeout'] = '10';


/*
$config['mailtype'] = 'html';
$config['protocol'] = 'smtp';
$config['smtp_host'] = '10.1.0.175';
$config['smtp_port'] = '25';
$config['smtp_user'] = '';
$config['smtp_pass'] = '';
$config['smtp_timeout'] = '10';
*/